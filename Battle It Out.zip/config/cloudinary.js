// Cloudinary Configuration
// Cloudinary credentials from Cloudinary Dashboard

export const cloudinaryConfig = {
  cloudName: "duez8qh9k",
  apiKey: "251452315393782",
  apiSecret: "**********", // Note: Keep this server-side only in production
  uploadPreset: "battleitout_unsigned", // Optional: Create an unsigned upload preset
};

export const cloudinaryDefaults = {
  folders: {
    images: "battleitout/images",
    videos: "battleitout/videos",
    profiles: "battleitout/profiles",
    thumbnails: "battleitout/thumbnails",
    diagnostics: {
      image: "battleitout/diagnostics/images",
      video: "battleitout/diagnostics/videos",
    },
  },
  transformations: {
    image: { w: 800, h: 800, c: "fill", q: 80 },
    video: { w: 1280, h: 720, c: "fill", q: 70, f: "mp4" },
  },
};

export const buildTransformationString = (transformations = {}) => {
  return Object.entries(transformations)
    .map(([key, value]) => `${key}_${value}`)
    .join(",");
};

// Base URL for Cloudinary transformations
export const cloudinaryBaseUrl = `https://res.cloudinary.com/${cloudinaryConfig.cloudName}`;

export default cloudinaryConfig;

