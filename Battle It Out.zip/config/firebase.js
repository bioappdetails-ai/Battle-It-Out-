// Firebase Configuration
// Firebase project credentials from Firebase Console

export const firebaseConfig = {
  apiKey: "AIzaSyBRwvFbjOf6qQBepXbUrzDHvgb9J0DPVSo",
  authDomain: "bettleitout.firebaseapp.com",
  projectId: "bettleitout",
  storageBucket: "bettleitout.firebasestorage.app",
  messagingSenderId: "907613423588",
  appId: "1:907613423588:web:2a54a70e62eb7f32d129f1",
  measurementId: "G-0EHV6XSW1T" // Optional, for Analytics
};

export default firebaseConfig;

